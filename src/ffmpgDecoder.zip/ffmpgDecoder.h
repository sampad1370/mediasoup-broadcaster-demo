#define VIDEOCAPTURE_API

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <cstring>
#include <math.h>
#include <string.h>
#include <algorithm>
#include <string>
#include <map>

extern "C"
{
#include <libavcodec/avcodec.h>
#include <libavcodec/avfft.h>

#include <libavdevice/avdevice.h>

#include <libavfilter/avfilter.h>
//#include <libavfilter/avfiltergraph.h>
#include <libavfilter/buffersink.h>
#include <libavfilter/buffersrc.h>

#include <libavformat/avformat.h>
#include <libavformat/avio.h>

// libav resample

#include <libavutil/opt.h>
#include <libavutil/common.h>
#include <libavutil/channel_layout.h>
#include <libavutil/imgutils.h>
#include <libavutil/mathematics.h>
#include <libavutil/samplefmt.h>
#include <libavutil/time.h>
#include <libavutil/opt.h>
#include <libavutil/pixdesc.h>
#include <libavutil/file.h>


// hwaccel
//#include "libavcodec/vdpau.h"
#include "libavutil/hwcontext.h"
#include "libavutil/hwcontext_vdpau.h"

// lib swresample

#include <libswscale/swscale.h>

#define INBUF_SIZE 4096



    class VideoCapture {
    public:

        VideoCapture(std::string filename);
        bool process();
    private:
        void decode(AVCodecContext *dec_ctx, AVFrame *frame, AVPacket *pkt);

    private:
        std::string m_filename;
        AVCodec* m_codec = nullptr;
        AVCodecParserContext* m_parser = nullptr;
        AVCodecContext* m_codecContex= nullptr;
        FILE* m_fileHandler;
        AVFrame* m_frame;

        uint8_t m_inbuf[INBUF_SIZE + AV_INPUT_BUFFER_PADDING_SIZE];
        uint8_t *m_data = nullptr;
        size_t   m_data_size;
        int m_ret;
        AVPacket *m_pkt= nullptr;
        std::map<uint32_t,AVFrame*> m_frames;
    };
}
